#!/usr/bin/python
# -*- coding: utf-8 -*-
'''app.py'''

import json
import urllib.request
from flask import Flask, render_template
app = Flask(__name__)


# function for display all market details

@app.route('/')
def display_market():
    url1 = 'https://api.bittrex.com/v3/markets/summaries'
    response1 = urllib.request.urlopen(url1)
    data1 = response1.read()
    json_data = json.loads(data1)
    return render_template('sample.html', market=json_data)


# function for display specific market details

@app.route('/<market_name>')
def get_market(market_name):
    url2 = 'https://api.bittrex.com/v3/markets/' + market_name \
        + '/summary'
    response2 = urllib.request.urlopen(url2)
    data2 = response2.read()
    market_data = json.loads(data2)
    return render_template('sample.html', market=market_data)

if __name__ == '__main__':
    app.run(debug=True)
