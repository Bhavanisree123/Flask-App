1. pip install flask
2. create app.py file in a project folder.
3. create the html file in templates folder.
4. run the application using python app.py
5. http://127.0.0.1:5000 for display all market details
6. http://127.0.0.1:5000/<market> for display particular market details.

unit testing:

1. pip install pytest
2. done unit testing for the api which ensure api url is working or not.
3. Test case passes successfully

Linting:
1. pip install pylint
2. achieve 7.78/10