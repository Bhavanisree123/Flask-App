import json
def test_index(app, client):
    res = client.get('/')
    assert res.status_code == 200
    expected = 200
    assert expected == res.status_code
